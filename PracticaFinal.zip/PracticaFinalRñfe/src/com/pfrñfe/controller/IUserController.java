package com.pfrñfe.controller;

public interface IUserController {

    public String findUserName(String userName);

}

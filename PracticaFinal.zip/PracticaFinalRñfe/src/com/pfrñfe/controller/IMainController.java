package com.pfrñfe.controller;

public interface IMainController {
    public void createCar(String marca, String modelo, String matricula, String anno);
}

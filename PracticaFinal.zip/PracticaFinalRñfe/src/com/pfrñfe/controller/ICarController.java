package com.pfrñfe.controller;

public interface ICarController {
    public void newCar(String modelo, String marca, String matricula, String anno);
}
